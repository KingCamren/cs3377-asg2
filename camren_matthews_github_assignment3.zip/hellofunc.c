#include <stdio.h>
#include "helloheader.h"

void hello_function() {
    printf("Hello from the function!\n");
}
