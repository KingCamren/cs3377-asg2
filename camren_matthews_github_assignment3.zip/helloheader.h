#ifndef HELLOHEADER_H
#define HELLOHEADER_H

void hello_function();

#endif // HELLOHEADER_H
