#ifndef FIBONACCI_H
#define FIBONACCI_H

long long fibonacci_n(int);

#endif // FIBONACCI_H